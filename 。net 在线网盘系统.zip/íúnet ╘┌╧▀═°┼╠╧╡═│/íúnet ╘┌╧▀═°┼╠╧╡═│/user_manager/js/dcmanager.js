﻿$(function() {
	$('#dctt').tree({
		onClick: function(node) {
			$('#dcdg').datagrid('load', {
				type: node.id
			});

			$('#dcdg').datagrid('loadData', {
				total: 0,
				rows: []
			});

		},
		data: [{
			"id": 1,
			"text": "所有文件"
		}, {
			"id": 2,
			"text": "文档"
		}, {
			"id": 3,
			"text": "影音"
		}, {
			"id": 4,
			"text": "压缩文件"
		}, {
			"id": 5,
			"text": "图片"
		}, {
			"id": 6,
			"text": "其它"
		}]
	});

	$('#dcdg').datagrid({

		fitColumns: true,
		striped: true,
		url: 'dcmanager_data.aspx',
		pagination: true,
		pageSize: 15,
		fit: true,
		rownumbers: true,
		toolbar: '#dctb',
		pageNumber: 1,
		pageList: [15, 30, 45, 60, 75],
		columns: [
			[{
					field: 'id',
					title: '文档编号',
					checkbox: true,
					width: 100
				},
				{
					field: 'dcname',
					title: '文件名',
					width: 100
				},
				{
					field: 'type',
					title: '文件类型',
					width: 100
				},
				{
					field: 'dcsize',
					title: '文件大小',
					width: 100
				},
				{
					field: 'addtime',
					title: '上传时间',
					width: 100
				}
			]
		]
	});

	$('#dcadd').dialog({
		title: '添加文档',
		width: 700,
		height: 400,
		minimizable: true,
		maximizable: true,
		closed: true,
		modal: true,
		buttons: [{
			text: '保存',
			iconCls: 'icon-save',
			handler: function() {

				$.ajax({
					url: 'userlogin.aspx',
					type: 'post',
					data: {
						action: "dcadd",
						bcname: $("#dciframe").contents().find("#fileinfo").val(),
						dcname: $("#dciframe").contents().find("#fileinfo1").val(),
						dcsize: $("#dciframe").contents().find("#filesize").val()
					},
					beforeSend: function() {
						$.messager.progress({
							text: '正在处理中...',
						});
					},
					success: function(data, response, status) {
						$.messager.progress('close');

						if(data == "1") {
							dcreload();
							$.messager.show({
								title: '操作成功',
								msg: '文档添加成功！',
								timeout: 5000,
								showType: 'slide'
							});
							$("#dciframe").contents().find("#fileinfo").val('');
							$("#dciframe").contents().find("#fileinfo1").val('');
							dcsize: $("#dciframe").contents().find("#filesize").val('');
							$('#dcadd').dialog('close');

						} else {
							$.messager.alert('添加失败！', '未知错误导致操作失败！错误信息：' + data, 'warning');
						}
					}
				});

			}
		}, {
			text: '关闭',
			iconCls: 'icon-redo',
			handler: function() {

				$('#dcadd').dialog('close');
			}
		}]
	});

})
$('#dcshare').dialog({
	title: '分享文档',
	width: 700,
	height: 400,
	minimizable: true,
	maximizable: true,
	closed: true,
	modal: true,
	buttons: [{
		text: '关闭',
		iconCls: 'icon-redo',
		handler: function() {

			$('#dcshare').dialog('close');
		}
	}]

})

function dcadd() {

	$('#dcadd').dialog('open');
}

function dcreload() {
	$('#dcdg').datagrid('reload');
}

function dcshare() {
	var rows = $('#dcdg').datagrid('getSelections');
	if(rows.length == 1) {
		$.ajax({
			url: 'userlogin.aspx',
			type: 'post',
			data: {
				action: "getdcdata",

				id: rows[0].id,

			},
			beforeSend: function() {
				$.messager.progress({
					text: '正在获取数据中...',
				});
			},
			success: function(data, response, status) {
				$.messager.progress('close');

				if(data != "") {

					$.messager.alert('操作成功！', ' 操作成功！' + data, 'warning');
					$('#share').val(data);
				} else {
					$.messager.alert('操作失败！', '未知错误导致操作失败！错误信息：' + data, 'warning');
				}
			}
		});

		$('#dcshare').dialog('open');
	} else if(rows.length > 1) {
		$.messager.alert('操作失败！', '只能分享一个文件' , 'warning');
	} else {
		$.messager.alert('操作失败！', '请选择要分享的文件' , 'warning');
	}

}

function dcdownload() {
	var rows = $('#dcdg').datagrid('getSelections');
	if(rows.length == 1) {
		$.ajax({
			url: 'userlogin.aspx',
			type: 'post',
			data: {
				action: "dcdownload",
				id: rows[0].id,
			},
			beforeSend: function() {
				$.messager.progress({
					text: '正在连接中...',
				});
			},
			success: function(data, response, status) {
				$.messager.progress('close');

				if(data != "") {
					$.messager.alert('下载成功！', '文件下载位置和浏览器下载位置保持一致哦！！', 'warning');
					location.href = "temp/" + data;
				} else {
					$.messager.alert('下载失败！', '未知错误！', 'warning');
				}
			}
		});
	} else if(rows.length > 1) {
		$.messager.alert('操作失败！', '只能同时下载一个文件', 'warning');
	} else {
		$.messager.alert('操作失败！', '请选择要下载的文件', 'warning');
	}
}

function dcremove() {
	var rows = $('#dcdg').datagrid('getSelections');
	if(rows.length == 1) {

		$.messager.confirm('操作确认', '您确定要删除所选择的文件吗?', function(r) {
			if(r) {
				$.ajax({
					url: 'userlogin.aspx',
					type: 'post',
					data: {
						action: "dcremove",
						id: rows[0].id,

					},
					beforeSend: function() {
						$.messager.progress({
							text: '正在处理中...',
						});
					},
					success: function(data, response, status) {
						$.messager.progress('close');

						if(data == "1") {
							dcreload();
							$.messager.show({
								title: '操作成功',
								msg: '1个文档被成功删除',
								timeout: 5000,
								showType: 'slide'
							});

						} else {
							$.messager.alert('操作失败！', '未知错误导致操作失败！错误信息：' + data, 'warning');
						}
					}
				});

			}
		});

	} else if(rows.length > 1) {

		var rows = $('#dcdg').datagrid('getSelections');
		var idstr = "";

		for(var i = 0; i < rows.length; i++) {
			if(idstr == "") {
				idstr = rows[i].id;
			} else {
				idstr = idstr + "&" + rows[i].id;
			}
		}
		//alert(idstr);

		$.messager.confirm('操作确认', '您确定要删除所选择的文档吗?', function(r) {
			if(r) {
				$.ajax({
					url: 'userlogin.aspx',
					type: 'post',
					data: {
						action: "dcremove",
						id: idstr,

					},
					beforeSend: function() {
						$.messager.progress({
							text: '正在处理中...',
						});
					},
					success: function(data, response, status) {
						$.messager.progress('close');

						if(data > 0) {
							dcreload();
							$.messager.show({
								title: '操作成功',
								msg: rows.length + '个文档被成功删除',
								timeout: 5000,
								showType: 'slide'
							});

						} else {
							$.messager.alert('操作失败！', '未知错误导致操作失败！错误信息：' + data, 'warning');
						}
					}
				});

			}
		});

	} else {
		$.messager.alert('验证失败！', '请选择要删除的行！', 'warning');
	}
}