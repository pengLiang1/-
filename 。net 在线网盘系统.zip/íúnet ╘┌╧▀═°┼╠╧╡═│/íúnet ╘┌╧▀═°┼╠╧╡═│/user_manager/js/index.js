$(function() {

	
	

	//管理员帐号验证
	$('#username').validatebox({
		required: true,
		missingMessage: '请输入帐号',
		
	});

	//管理员密码验证
	$('#password').validatebox({
		required: true,
		
		missingMessage: '请输入密码',
		invalidMessage: '密码长度不对',
	});


	


});


function login()
{
if (!$('#username').validatebox('isValid')) {
			$('#username').focus();
		} else if (!$('#password').validatebox('isValid')) {
			$('#password').focus();
		} else {

			$.ajax({
				url: 'userlogin.aspx',
				type: 'post',
				data: {
					action:"userlogin",
					manager: $('#username').val(),
					password: $('#password').val(),
				},
				beforeSend: function() {
					$.messager.progress({
						text: '正在登录中...',
					});
				},
				success: function(data, response, status) {
					$.messager.progress('close');

					if (data =="1") {

						location.href = 'Default.aspx';

					} else {
						$.messager.alert('登录失败！', '用户名或密码错误！', 'warning', function() {
							$('#password').select();
						});
					}
				}
			});
		}
        
}

