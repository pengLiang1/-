﻿$(function() {

})
function updateinfo() {
	
		$.ajax({
		url: 'userlogin.aspx',
		type: 'post',
		data: {
			action: "updatepersoninfo",
		   realname: $('#realname').val(),
		   mobile: $('#mobile').val(),
		   email: $('#email').val(),
		   qq: $('#QQ').val(),
              
		},
		beforeSend: function() {
			$.messager.progress({
				text: '正在加载中...',
			});
		},
		success: function(data, response, status) {
			$.messager.progress('close');
			if(data == "1") {

			$.messager.alert('修改成功！', '个人信息修改成功！', 'warning');
			} else {
				$.messager.alert('修改失败！', '未知错误！', 'warning');
			}
		}

	});
	
}

function clearinfo() {
	
	$('#realname').val('');
	$('#mobile').val('');
	$('#email').val('');
	$('#qq').val('');
}