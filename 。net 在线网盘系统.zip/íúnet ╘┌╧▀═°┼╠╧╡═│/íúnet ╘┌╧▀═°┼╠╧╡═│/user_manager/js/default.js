﻿$(function() {
	$('#dg3').datagrid({

		fitColumns: true,
		striped: true,
		url: 'ggmanager_data.aspx',
		pagination: true,
		pageSize: 15,
		fit: true,
		rownumbers: true,
		pageNumber: 1,
		pageList: [15, 30, 45, 60, 75],

		columns: [
			[{
					field: 'title',
					title: '主题',
					width: 100
				},
				{
					field: 'addtime',
					title: '发布时间',
					width: 100
				},
				{
					field: 'adduser',
					title: '发布人',
					width: 100
				}
			]
		]

	});

	$('#tt').tree({
		url: 'nav.aspx',
		lines: true,
		onClick: function(node) {

			if(node.text == "用户管理") {
				if($('#tabs').tabs('exists', node.text)) {
					$('#tabs').tabs('select', node.text)
				} else {

					$('#tabs').tabs('add', {
						title: node.text,
						selected: true,
						closable: true,
						href: 'usermanager.aspx'

					});
				}

			} else if(node.text == "密码设置") {
				if($('#tabs').tabs('exists', node.text)) {
					$('#tabs').tabs('select', node.text)
				} else {

					$('#tabs').tabs('add', {
						title: node.text,
						selected: true,
						closable: true,
						href: 'updatapwd.aspx'

					});
				}

			} else if(node.text == "公告管理") {
				if($('#tabs').tabs('exists', node.text)) {
					$('#tabs').tabs('select', node.text)
				} else {

					$('#tabs').tabs('add', {
						title: node.text,
						selected: true,
						closable: true,
						href: 'ggmanager.aspx'

					});
				}

			} else if(node.text == "文档管理") {
				if($('#tabs').tabs('exists', node.text)) {
					$('#tabs').tabs('select', node.text)
				} else {

					$('#tabs').tabs('add', {
						title: node.text,
						selected: true,
						closable: true,
						href: 'dcmanager.aspx'

					});
				}

			} else if(node.text == "信息修改") {
				if($('#tabs').tabs('exists', node.text)) {
					$('#tabs').tabs('select', node.text)
				} else {

					$('#tabs').tabs('add', {
						title: node.text,
						selected: true,
						closable: true,
						href: 'updatapesoninfo.aspx'

					});
				}

			}
		}
	});
	$('#win10').dialog({
		title: '公告查看',
		width: 400,
		height: 500,
		closed: true,
		modal: true,
		resizable: true,
		buttons: [{
			text: '关闭',
			iconCls: 'icon-clear',
			handler: function() {

				$('#win10').dialog('close');
			}
		}],

	});

	$('#dg3').datagrid({
		onDblClickRow: function(rowIndex, rowData) {
          
			$('#text10').val(rowData.title);
			$('#div10').html(decodeURIComponent(rowData.g_contenthtml));
			$('#win10').dialog('open');
		}
	});

	$('#tabs').tabs({
		border: false,
		fit: true,

	});

})