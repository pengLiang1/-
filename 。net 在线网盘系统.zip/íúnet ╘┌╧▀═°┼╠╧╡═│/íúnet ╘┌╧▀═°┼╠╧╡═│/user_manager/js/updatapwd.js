﻿$(function() {
	$.ajax({
		url: 'userlogin.aspx',
		type: 'post',
		data: {
			action: "updatepwd"

		},
		beforeSend: function() {
			$.messager.progress({
				text: '正在加载中...',
			});
		},
		success: function(data, response, status) {
			$.messager.progress('close');
			if(data != "") {
				$('#username').val(data)

			} else {
				$.messager.alert('删除失败！', '未知错误！', 'warning');
			}
		}

	});
	
})
	function datasave() {
		if($('#pwd').val()==$('#rpwd').val()){
			$.ajax({
		url: 'userlogin.aspx',
		type: 'post',
		data: {
			action: "comparepwd",
           password: $('#password').val(),
		},
		beforeSend: function() {
			$.messager.progress({
				text: '正在加载中...',
			});
		},
		success: function(data, response, status) {
			$.messager.progress('close');
			if(data =="1") {
				$.ajax({
					url: 'userlogin.aspx',
					type: 'post',
					data: {
						action: "updatenewpwd",
                 password: $('#pwd').val(),
                 username: $('#username').val(),
					},
					beforeSend: function() {
						$.messager.progress({
							text: '正在加载中...',
						});
					},
					success: function(data, response, status) {
						$.messager.progress('close');
						if(data == "1") {
						$.messager.alert('操作成功！', '密码修改成功！', 'warning');

						} else {
							$.messager.alert('操作失败！', '未知错误！', 'warning');
						}
					}

				});

			} else {
				$.messager.alert('验证失败！', '原密码输入错误！', 'warning');
			}
		}

	});
	
		}
		else{
			$.messager.alert('验证失败！', '两次密码输入不一致！', 'warning');
		}
}

function dataclear() {
	
	$('#password').val('');
	$('#pwd').val('');
	$('#rpwd').val('');
}