﻿$(function() {

	
})

function getdc() {
	$.ajax({
		url: 'userlogin.aspx',
		type: 'post',
		data: {
			action: "sharedownload",
			share: $('#tiqu').val(),
		},
		beforeSend: function() {
			$.messager.progress({
				text: '正在连接中...',
			});
		},
		success: function(data, response, status) {
			$.messager.progress('close');

			if(data != "") {
				location.href = "temp/" + data;
			} else {
				$.messager.alert('提取失败！', '未知错误！', 'warning');
			}
		}
	});
}