﻿var editor1;
var editor2;
$(function() {

	$('#dg2').datagrid({

		fitColumns: true,
		striped: true,
		url: 'ggmanager_data.aspx',
		pagination: true,
		pageSize: 15,
		fit: true,
		rownumbers: true,
		toolbar: '#tb2',
		pageNumber: 1,
		pageList: [15, 30, 45, 60, 75],
		columns: [
			[{
					field: 'id',
					title: '用户编号',
					checkbox: true,
					width: 100
				},
				{
					field: 'title',
					title: '主题',
					width: 100
				},
				{
					field: 'addtime',
					title: '发布时间',
					width: 100
				},
				{
					field: 'adduser',
					title: '发布人',
					width: 100
				}
			]
		]
	});

	$('#dd2').dialog({
		title: '添加公告',
		width: 700,
		height: 400,
		minimizable: true,
		maximizable: true,
		closed: true,
		modal: true,
		buttons: [{
			text: '保存',
			iconCls: 'icon-save',
			handler: function() {

				$.ajax({
					url: 'userlogin.aspx',
					type: 'post',
					data: {
						action: "ggadd",
						title: $('#title').val(),
						g_contenthtml: encodeURIComponent(editor1.html()),

					},
					beforeSend: function() {
						$.messager.progress({
							text: '正在处理中...',
						});
					},
					success: function(data, response, status) {
						$.messager.progress('close');

						if(data == "1") {
							userreload_gg();
							$.messager.show({
								title: '操作成功',
								msg: '公告添加成功！',
								timeout: 5000,
								showType: 'slide'
							});

							$('#title').val('');
							editor1.html('');

							$('#dd2').dialog('close');

						} else {
							$.messager.alert('添加失败！', '未知错误导致操作失败！错误信息：' + data, 'warning');
						}
					}
				});

			}
		}, {
			text: '关闭',
			iconCls: 'icon-redo',
			handler: function() {

				$('#dd2').dialog('close');
			}
		}]
	});
	$('#dd2_edit').dialog({

		title: '编辑公告',
		width: 700,
		height: 400,
		closed: true,
		modal: true,
		buttons: [{
			text: '保存',
			iconCls: 'icon-save',
			handler: function() {
				var rows = $('#dg2').datagrid('getSelections');

				$.ajax({
					url: 'userlogin.aspx',
					type: 'post',
					data: {
						action: "ggupdate",
						id: rows[0].id,
						title: $('#title_edit').val(),

						g_contenthtml: encodeURIComponent(editor2.html()),

					},
					beforeSend: function() {
						$.messager.progress({
							text: '正在处理中...',
						});
					},
					success: function(data, response, status) {
						$.messager.progress('close');

						if(data == "1") {
							userreload_gg();
							$.messager.show({
								title: '操作成功',
								msg: '公告修改成功！',
								timeout: 5000,
								showType: 'slide'
							});

							$('#dd2_edit').dialog('close');

						} else {
							$.messager.alert('登录失败！', '未知错误导致操作失败！错误信息：' + data, 'warning');
						}
					}
				});

			}
		}, {
			text: '关闭',
			iconCls: 'icon-redo',
			handler: function() {

				$('#dd2_edit').dialog('close');
			}
		}]

	});
	editor2 = KindEditor.create('#content2', {
		cssPath: 'kindeditor/plugins/code/prettify.css',
		uploadJson: 'kindeditor/jsp/upload_json.jsp',
		fileManagerJson: 'kindeditor/jsp/file_manager_json.jsp',
		allowFileManager: true,

	});
})

function userremove_gg() {
	var rows = $('#dg2').datagrid('getSelections');
	if(rows.length == 1) {

		$.messager.confirm('操作确认', '您确定要删除所选择的数据吗?', function(r) {
			if(r) {
				$.ajax({
					url: 'userlogin.aspx',
					type: 'post',
					data: {
						action: "ggremove",
						id: rows[0].id,

					},
					beforeSend: function() {
						$.messager.progress({
							text: '正在处理中...',
						});
					},
					success: function(data, response, status) {
						$.messager.progress('close');

						if(data == "1") {
							userreload_gg();
							$.messager.show({
								title: '操作成功',
								msg: '1条公告被成功删除',
								timeout: 5000,
								showType: 'slide'
							});

						} else {
							$.messager.alert('操作失败！', '未知错误导致操作失败！错误信息：' + data, 'warning');
						}
					}
				});

			}
		});

	} else if(rows.length > 1) {

		var rows = $('#dg2').datagrid('getSelections');
		var idstr = "";

		for(var i = 0; i < rows.length; i++) {
			if(idstr == "") {
				idstr = rows[i].id;
			} else {
				idstr = idstr + "&" + rows[i].id;
			}
		}
		//alert(idstr);

		$.messager.confirm('操作确认', '您确定要删除所选择的数据吗?', function(r) {
			if(r) {
				$.ajax({
					url: 'userlogin.aspx',
					type: 'post',
					data: {
						action: "ggremove",
						id: idstr,

					},
					beforeSend: function() {
						$.messager.progress({
							text: '正在处理中...',
						});
					},
					success: function(data, response, status) {
						$.messager.progress('close');

						if(data > 0) {
							userreload_gg();
							$.messager.show({
								title: '操作成功',
								msg: data + '条数据被成功删除',
								timeout: 5000,
								showType: 'slide'
							});

						} else {
							$.messager.alert('登录失败！', '未知错误导致操作失败！错误信息：' + data, 'warning');
						}
					}
				});

			}
		});

	} else {
		$.messager.alert('验证失败！', '请选择要删除的行！', 'warning');
	}
}

function userreload_gg() {
	$('#dg2').datagrid('reload');
}

function useredit_gg() {
	var rows = $('#dg2').datagrid('getSelections');
	if(rows.length == 1) {

		$.ajax({
			url: 'userlogin.aspx',
			type: 'post',
			data: {
				action: "getgg",

				userid: rows[0].id,

			},
			beforeSend: function() {
				$.messager.progress({
					text: '正在获取数据中...',
				});
			},
			success: function(data, response, status) {
				$.messager.progress('close');

				if(data) {
					var obj = $.parseJSON(data);

					$('#title_edit').val(obj[0].title);
      
					editor2.html(decodeURIComponent(obj[0].g_contenthtml));

					$('#dd2_edit').dialog('open');

				} else {
					$.messager.alert('操作失败！', '未知错误导致操作失败！错误信息：' + data, 'warning');
				}
			}
		});

		$('#dd2_edit').dialog('open');

	} else if(rows.length > 1) {

		$.messager.alert('验证失败！', '编辑只能选择一行！', 'warning');

	} else {
		$.messager.alert('验证失败！', '请选择要编辑的行！', 'warning');
	}
}

function useradd_gg() {

	editor1 = KindEditor.create('#content1', {
		cssPath: 'kindeditor/plugins/code/prettify.css',
		uploadJson: 'kindeditor/jsp/upload_json.jsp',
		fileManagerJson: 'kindeditor/jsp/file_manager_json.jsp',
		allowFileManager: true,

	});

	$('#dd2').dialog('open');
}