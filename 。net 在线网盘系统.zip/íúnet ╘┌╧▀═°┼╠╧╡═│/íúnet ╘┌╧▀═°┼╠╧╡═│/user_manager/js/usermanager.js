$(function() {

	$('#dg').datagrid({

		fitColumns: true,
		striped: true,
		url: 'user_data.aspx',
		pagination: true,
		pageSize: 15,
		fit: true,
		rownumbers: true,
		toolbar: '#tb',
		pageNumber: 1,
		pageList: [15, 30, 45, 60, 75],
		columns: [
			[{
					field: 'id',
					title: '用户编号',
					checkbox: true,
					width: 100
				},
				{
					field: 'username',
					title: '用户名',
					width: 100
				},
				{
					field: 'realname',
					title: '真实姓名',
					width: 100,
				}
			]
		]
	});

	$('#dd').dialog({
		title: '添加用户',
		width: 400,
		height: 400,
		closed: true,
		modal: true,
		buttons: [{
			text: '保存',
			iconCls: 'icon-save',
			handler: function() {

				if (!$('#username').validatebox('isValid')) {
					$('#username').foucs();
					return;
				}
				if (!$('#password').validatebox('isValid')) {
					$('#password').foucs();
					return;
				}
				
				if (!$('#usertype').combobox('isValid')) {
					$('#usertype').foucs();
					return;
				}
				if (!$('#access').combotree('isValid')) {
					$('#access').foucs();
					return;
				}



				$.ajax({
					url: 'userlogin.aspx',
					type: 'post',
					data: {
						action: "useradd",
						username: $('#username').val(),
						password: $('#password').val(),
						realname: $('#realname').val(),
						mobile: $('#mobile').val(),
						email: $('#email').val(),
						QQ: $('#QQ').val(),
						usertype: $('#usertype').combobox('getValue'),
						useraccess: $('#access').combotree('getText'),

					},
					beforeSend: function() {
						$.messager.progress({
							text: '正在处理中...',
						});
					},
					success: function(data, response, status) {
						$.messager.progress('close');

						if (data == "1") {
							userreload();
							$.messager.show({
								title: '操作成功',
								msg: '用户添加成功！',
								timeout: 5000,
								showType: 'slide'
							});


							$('#username').val(''),
								$('#password').val(''),
								$('#realname').val(''),
								$('#mobile').val(''),
								$('#email').val(''),
								$('#QQ').val(''),
								$('#dd').dialog('close');


						} else {
							$.messager.alert('登录失败！', '未知错误导致操作失败！错误信息：' + data, 'warning');
						}
					}
				});




			}
		}, {
			text: '关闭',
			iconCls: 'icon-redo',
			handler: function() {

				$('#dd').dialog('close');
			}
		}]
	});


	$('#dd_edit').dialog({
		title: '编辑用户',
		width: 400,
		height: 400,
		closed: true,
		modal: true,
		buttons: [{
			text: '保存',
			iconCls: 'icon-save',
			handler: function() {

				if (!$('#username_edit').validatebox('isValid')) {
					$('#username_edit').foucs();
					return;
				}
				if (!$('#password_edit').validatebox('isValid')) {
					$('#password_edit').foucs();
					return;
				}
				if (!$('#realname_edit').validatebox('isValid')) {
					$('#realname').foucs();
					return;
				}
				if (!$('#mobile_edit').validatebox('isValid')) {
					$('#mobile_edit').foucs();
					return;
				}
				if (!$('#usertype_edit').combobox('isValid')) {
					$('#usertype_edit').foucs();
					return;
				}
				if (!$('#access_edit').combotree('isValid')) {
					$('#access_edit').foucs();
					return;
				}


var rows = $('#dg').datagrid('getSelections');
				$.ajax({
					url: 'userlogin.aspx',
					type: 'post',
					data: {
						action: "userupdate",
						id:rows[0].id,
						username: $('#username_edit').val(),
						password: $('#password_edit').val(),
						realname: $('#realname_edit').val(),
						mobile: $('#mobile_edit').val(),
						email: $('#email_edit').val(),
						QQ: $('#QQ_edit').val(),
						usertype: $('#usertype_edit').combobox('getValue'),
						useraccess: $('#access_edit').combotree('getText'),

					},
					beforeSend: function() {
						$.messager.progress({
							text: '正在处理中...',
						});
					},
					success: function(data, response, status) {
						$.messager.progress('close');
                      
						if (data == "1") {
							userreload();
							$.messager.show({
								title: '操作成功',
								msg: '用户修改成功！',
								timeout: 5000,
								showType: 'slide'
							});


							 $('#username_edit').val(''),
								$('#password_edit').val(''),
								$('#realname_edit').val(''),
								$('#mobile_edit').val(''),
								$('#email_edit').val(''),
								$('#QQ_edit').val(''),
								$('#dd_edit').dialog('close');


						} else {
							$.messager.alert('登录失败！', '未知错误导致操作失败！错误信息：' + data, 'warning');
						}
					}
				});




			}
		}, {
			text: '关闭',
			iconCls: 'icon-redo',
			handler: function() {

				$('#dd_edit').dialog('close');
			}
		}]
	});

});

function userremove() {
	var rows = $('#dg').datagrid('getSelections');
	if (rows.length == 1) {

		$.messager.confirm('操作确认', '您确定要删除所选择的数据吗?', function(r) {
			if (r) {
				$.ajax({
					url: 'userlogin.aspx',
					type: 'post',
					data: {
						action: "userremove",
						id: rows[0].id,

					},
					beforeSend: function() {
						$.messager.progress({
							text: '正在处理中...',
						});
					},
					success: function(data, response, status) {
						$.messager.progress('close');

						if (data == "1") {
							userreload();
							$.messager.show({
								title: '操作成功',
								msg: '1条数据被成功删除',
								timeout: 5000,
								showType: 'slide'
							});

						} else {
							$.messager.alert('登录失败！', '未知错误导致操作失败！错误信息：' + data, 'warning');
						}
					}
				});

			}
		});

	} else if (rows.length > 1) {

		var rows = $('#dg').datagrid('getSelections');
		var idstr = "";

		for (var i = 0; i < rows.length; i++) {
			if (idstr == "") {
				idstr = rows[i].id;
			} else {
				idstr = idstr + "&" + rows[i].id;
			}
		}
		//alert(idstr);

		$.messager.confirm('操作确认', '您确定要删除所选择的数据吗?', function(r) {
			if (r) {
				$.ajax({
					url: 'userlogin.aspx',
					type: 'post',
					data: {
						action: "userremove",
						id: idstr,

					},
					beforeSend: function() {
						$.messager.progress({
							text: '正在处理中...',
						});
					},
					success: function(data, response, status) {
						$.messager.progress('close');

						if (data > 0) {
							userreload();
							$.messager.show({
								title: '操作成功',
								msg: data + '条数据被成功删除',
								timeout: 5000,
								showType: 'slide'
							});

						} else {
							$.messager.alert('登录失败！', '未知错误导致操作失败！错误信息：' + data, 'warning');
						}
					}
				});

			}
		});

	} else {
		$.messager.alert('验证失败！', '请选择要删除的行！', 'warning');
	}
}

function userreload() {
	$('#dg').datagrid('reload');
}

function useredit() {
	var rows = $('#dg').datagrid('getSelections');
	if (rows.length == 1) {

		$.ajax({
			url: 'userlogin.aspx',
			type: 'post',
			data: {
				action: "getuser",
				userid: rows[0].id,

			},
			beforeSend: function() {
				$.messager.progress({
					text: '正在获取数据中...',
				});
			},
			success: function(data, response, status) {
				$.messager.progress('close');

				if (data) {
					var obj = $.parseJSON(data);
					//alert(obj[0].username);
            $('#username_edit').val(obj[0].username),
						$('#password_edit').val(obj[0].password),
						$('#realname_edit').val(obj[0].realname),
						$('#mobile_edit').val(obj[0].mobile),
						$('#email_edit').val(obj[0].email),
						$('#QQ_edit').val(obj[0].qq), 
						
						
						$('#access_edit').combotree({
							url: 'nav.aspx',
							required: true,
							multiple: true,
							onLoadSuccess: function(node, data) {
								if (data) {
									var _this = this;
									$(_this).tree('expandAll');
								}
							},
						});
						$('#usertype_edit').combobox({
							required: true,
							valueField: 'id',
							textField: 'text',
							data: [{
								"id": 1,
								"text": "普通用户"
							}, {
								"id": 2,
								"text": "管理员"
							}]
						});
						
						$('#usertype_edit').combobox('setValue',obj[0].usertype);
						
						var auth=obj[0].access.split('&');
						
						$('#access_edit').combotree('setValues',auth);
						
						$('#username_edit').validatebox({
								required: true,
								missingMessage: '请输入用户帐号',
						
							});
							$('#password_edit').validatebox({
								required: true,
								missingMessage: '请输入用户密码',
						
							});
							$('#realname_edit').validatebox({
								required: true,
								missingMessage: '请输入真实姓名',
						
							});
							$('#mobile_edit').validatebox({
								required: true,
								missingMessage: '请输入移动电话',
						
							});
						$('#dd_edit').dialog('open');


				} else {
					$.messager.alert('登录失败！', '未知错误导致操作失败！错误信息：' + data, 'warning');
				}
			}
		});



	} else if (rows.length > 1) {

		$.messager.alert('验证失败！', '编辑只能选择一行！', 'warning');

	} else {
		$.messager.alert('验证失败！', '请选择要编辑的行！', 'warning');
	}
}

function useradd() {


	$('#username').validatebox({
		required: true,
		missingMessage: '请输入用户帐号',

	});
	$('#password').validatebox({
		required: true,
		missingMessage: '请输入用户密码',

	});
	$('#realname').validatebox({
		required: true,
		missingMessage: '请输入真实姓名',

	});
	$('#mobile').validatebox({
		required: true,
		missingMessage: '请输入移动电话',

	});
	$('#access').combotree({
		url: 'nav.aspx',
		required: true,
		multiple: true,
		onLoadSuccess: function(node, data) {
			if (data) {
				var _this = this;
				$(_this).tree('expandAll');
			}
		},
	});
	$('#usertype').combobox({
		required: true,
		valueField: 'id',
		textField: 'text',
		data: [{
			"id": 1,
			"text": "普通用户"
		}, {
			"id": 2,
			"text": "管理员"
		}]
	});
	$('#dd').dialog('open');
}
