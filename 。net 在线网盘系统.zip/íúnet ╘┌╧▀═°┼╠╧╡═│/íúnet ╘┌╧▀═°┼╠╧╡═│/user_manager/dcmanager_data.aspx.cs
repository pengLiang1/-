﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class dcmanager_data : System.Web.UI.Page
{
    localhost.dbuser dbu = new localhost.dbuser();
    protected void Page_Load(object sender, EventArgs e)
    {
        string page = Request.Form["page"].ToString();
        string pagesize = Request.Form["rows"].ToString();
         string userdata ="";
         int i = 0;
        try
        {
            string type = Request.Form["type"].ToString();
            string where = "1=1";
            if (type != "" && type != "1")
            {
                where = where + "and type='" + type + "'";
            }

          userdata = dbu.dcdata(Convert.ToInt32(page), Convert.ToInt32(pagesize), where);
            Response.Write(userdata);
            i=1;
        }
        catch
        {

        }
        if (i == 0)
        {
            userdata = dbu.getdcmanagerdata(Convert.ToInt32(page), Convert.ToInt32(pagesize));
            Response.Write(userdata);
        }
    }
}