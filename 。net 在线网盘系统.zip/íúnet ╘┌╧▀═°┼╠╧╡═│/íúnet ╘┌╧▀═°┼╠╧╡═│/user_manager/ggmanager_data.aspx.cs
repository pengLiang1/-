﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class ggmanager_data : System.Web.UI.Page
{
    localhost.dbuser dbu = new localhost.dbuser();
    protected void Page_Load(object sender, EventArgs e)
    {
        string page = Request.Form["page"].ToString();
        string pagesize = Request.Form["rows"].ToString();
        string userdata = dbu.getggmanagerdata(Convert.ToInt32(page), Convert.ToInt32(pagesize));
        Response.Write(userdata);
    }
}